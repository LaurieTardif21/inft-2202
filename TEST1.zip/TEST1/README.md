# Test 1

---

Show two lists of movies.  One of all movies, and one of just your favourites.

The two lists should be basically the same.

If there are no pinned movies, show a message that says there are no pinned movies.

There should be a button that adds and removes movies from your pinned list.
