// contact validation here

//name: laurie tardif
//description: contact functions
// course: inft 2202
// date: 02/09/2025